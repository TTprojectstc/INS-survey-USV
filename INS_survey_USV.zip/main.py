# Main control script
