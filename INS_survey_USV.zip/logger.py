# Data logging functionality
