# Button logic for start, stop, abort
